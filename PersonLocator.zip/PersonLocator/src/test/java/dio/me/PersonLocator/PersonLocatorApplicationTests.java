package dio.me.PersonLocator;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PersonLocatorApplicationTests {

	@Test
	void contextLoads() {
	}

}
